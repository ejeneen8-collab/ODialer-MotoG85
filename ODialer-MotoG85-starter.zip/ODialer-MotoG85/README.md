# ODialer-MotoG85

A clean Android starter project for a Moto G85 dialer.

This is the foundation only. It currently contains a basic Compose dial-pad UI.
Default Phone role, contacts, call history, SMS handling, in-call UI, settings,
and any supported call-recording integration must be implemented and tested
separately on the target device. Two-way call recording is not guaranteed by Android.
