package com.motog85.odialer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ODialerStarterScreen() }
    }
}

@Composable
private fun ODialerStarterScreen() {
    var number by remember { mutableStateOf("") }
    val background = Brush.verticalGradient(
        listOf(Color(0xFF10152E), Color(0xFF263B69), Color(0xFF111522))
    )
    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            modifier = Modifier.fillMaxSize().background(background).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ODialer", color = Color.White.copy(alpha = .8f), fontSize = 15.sp)
                Spacer(Modifier.height(36.dp))
                Text(number.ifEmpty { "Enter phone number" }, color = Color.White,
                    fontSize = 28.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.height(12.dp))
                Text("Moto G85 • Android", color = Color.White.copy(alpha = .6f), fontSize = 13.sp)
            }
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                val rows = listOf(
                    listOf("1", "2", "3"), listOf("4", "5", "6"),
                    listOf("7", "8", "9"), listOf("*", "0", "#")
                )
                rows.forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        row.forEach { digit ->
                            FilledTonalButton(
                                onClick = { number += digit },
                                modifier = Modifier.weight(1f).height(68.dp),
                                shape = CircleShape,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color.White.copy(alpha = .16f),
                                    contentColor = Color.White
                                )
                            ) { Text(digit, fontSize = 25.sp) }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { if (number.isNotEmpty()) number = number.dropLast(1) }) {
                        Icon(Icons.Default.Backspace, contentDescription = "Delete", tint = Color.White)
                    }
                    Button(
                        onClick = { /* Calling will be wired after default-dialer role and permissions. */ },
                        modifier = Modifier.size(76.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18B968))
                    ) { Icon(Icons.Default.Call, contentDescription = "Call", tint = Color.White) }
                    IconButton(onClick = { number = "" }) {
                        Text("C", color = Color.White, fontSize = 20.sp)
                    }
                }
            }
            Text(
                "Starter build • Calling, contacts, SMS and recording are added in later steps",
                color = Color.White.copy(alpha = .55f), fontSize = 11.sp
            )
        }
    }
}
